package com.siemens.medical.bpuia.samples.logging.pojo.serverloggerpojo;

import org.apache.log4j.Logger;

public class ProcessLoggerPojo {

	Logger logger = null;

	public ProcessLoggerPojo() {
		// initialize logger
		logger = Logger.getLogger(this.getClass());
	}

	public void logTrace(String msg) {
		if (logger.isTraceEnabled()) {
			logger.trace(msg);
		}
	}

	public void logDebug(String msg) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg);
		}
	}

	public void logInfo(String msg) {
		if (logger.isInfoEnabled()) {
			logger.info(msg);
		}
	}

	public void logWarn(String msg) {

		logger.warn(msg);
	}

	public void logError(String msg) {
		logger.error(msg);
	}

	public void logFatal(String msg) {
		logger.fatal(msg);
	}
}
