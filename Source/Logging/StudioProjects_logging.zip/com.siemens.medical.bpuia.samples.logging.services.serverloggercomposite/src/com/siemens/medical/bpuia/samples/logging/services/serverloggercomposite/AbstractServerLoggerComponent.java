package com.siemens.medical.bpuia.samples.logging.services.serverloggercomposite;

import com.siemens.medical.bpuia.samples.logging.services.serverlogger.ServerLogger;
import com.siemens.medical.bpuia.samples.logging.services.serverLogger.LogToServerResponseDocument;
import com.siemens.medical.bpuia.samples.logging.services.serverLogger.LogToServerRequestDocument;

/**
 * Abstract interface generated for component "ServerLoggerComponent".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.siemens.medical.bpuia.samples.logging.services.serverloggercomposite.AbstractServerLoggerComponent AbstractServerLoggerComponent}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractServerLoggerComponent implements ServerLogger {

	/**
	 * Implementation of the WSDL operation: LogToServer	 */
	public abstract LogToServerResponseDocument logToServer(
			LogToServerRequestDocument parameters);

}
