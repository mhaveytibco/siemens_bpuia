package com.siemens.medical.bpuia.samples.logging.services.serverloggercomposite;

import org.apache.log4j.Logger;
import org.osoa.sca.annotations.Destroy;
import org.osoa.sca.annotations.Init;

import com.siemens.medical.bpuia.samples.logging.services.serverLogger.LogToServerRequestDocument;
import com.siemens.medical.bpuia.samples.logging.services.serverLogger.LogToServerResponseDocument;

/**
 * Implementation of ServerLoggerComponent component.
 * 
 */
public class ServerLoggerComponent extends AbstractServerLoggerComponent {

	Logger logger = null;

	/**
	 * Initialization of ServerLoggerComponent component.
	 */
	@Init
	public void init() {
		logger = Logger.getLogger(this.getClass());
		// Component initialization code.
		// All properties are initialized and references are injected.
		// The Reference cannot be invoked unless "Start Service First" policy
		// has been applied on it.
	}

	/**
	 * Disposal of ServerLoggerComponent component.
	 */
	@Destroy
	public void destroy() {
		// Component disposal code.
		// All properties are disposed.
	}

	/**
	 * Implementation of the WSDL operation: LogToServer
	 */
	public LogToServerResponseDocument logToServer(
			LogToServerRequestDocument parameters) {

		String msg = parameters.getLogToServerRequest().getMessage();
		String level = parameters.getLogToServerRequest().getLevel();
		String result = null;
		try {
			if (level.equals("debug") && logger.isDebugEnabled()) {
				logger.debug(msg);
			} else if (level.equals("trace") && logger.isTraceEnabled()) {
				logger.trace(msg);
			} else if (level.equals("info") && logger.isInfoEnabled()) {
				logger.info(msg);
			} else if (level.equals("warn")) {
				logger.warn(msg);
			} else if (level.equals("error")) {
				logger.error(msg);
			} else if (level.equals("fatal")) {
				logger.fatal(msg);
			} else {
				throw new RuntimeException("Illegal level");
			}

			result = "OK";
		} catch (Throwable t) {
			logger.error(" UNABLE TO LOG msg*" + msg + "* level *" + level
					+ "*");
			t.printStackTrace();
			result = t.toString();
		}

		// Add the business logic here
		LogToServerResponseDocument resp = LogToServerResponseDocument.Factory
				.newInstance();
		resp.addNewLogToServerResponse().setOutcome(result);
		return resp;
	}
}
