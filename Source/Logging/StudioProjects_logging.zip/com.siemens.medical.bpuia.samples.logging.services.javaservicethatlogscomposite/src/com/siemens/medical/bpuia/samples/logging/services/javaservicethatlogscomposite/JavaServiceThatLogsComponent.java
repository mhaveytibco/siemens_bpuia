package com.siemens.medical.bpuia.samples.logging.services.javaservicethatlogscomposite;

import org.osoa.sca.annotations.Init;
import org.osoa.sca.annotations.Destroy;

import com.siemens.medical.bpuia.samples.logging.services.javaServiceThatLogs.JavaOperationRequestDocument;
import com.siemens.medical.bpuia.samples.logging.services.javaServiceThatLogs.JavaOperationResponseDocument;
import org.apache.log4j.Logger;

/**
 * Implementation of JavaServiceThatLogsComponent component.
 * 
 */
public class JavaServiceThatLogsComponent extends
		AbstractJavaServiceThatLogsComponent {

	Logger logger = null;

	/**
	 * Initialization of JavaServiceThatLogsComponent component.
	 */
	@Init
	public void init() {
		logger = Logger.getLogger(this.getClass());

		// Component initialization code.
		// All properties are initialized and references are injected.
		// The Reference cannot be invoked unless "Start Service First" policy
		// has been applied on it.
	}

	/**
	 * Disposal of JavaServiceThatLogsComponent component.
	 */
	@Destroy
	public void destroy() {
		// Component disposal code.
		// All properties are disposed.
	}

	/**
	 * Implementation of the WSDL operation: JavaOperation
	 */
	public JavaOperationResponseDocument javaOperation(
			JavaOperationRequestDocument parameters) {

		String input = parameters.getJavaOperationRequest().getIn();
		String output = input.toUpperCase();

		logger.info("JavaService: input *" + input + "* output *" + output
				+ "*");

		JavaOperationResponseDocument resp = JavaOperationResponseDocument.Factory
				.newInstance();
		resp.addNewJavaOperationResponse().setOut(output);
		return resp;
	}

}
