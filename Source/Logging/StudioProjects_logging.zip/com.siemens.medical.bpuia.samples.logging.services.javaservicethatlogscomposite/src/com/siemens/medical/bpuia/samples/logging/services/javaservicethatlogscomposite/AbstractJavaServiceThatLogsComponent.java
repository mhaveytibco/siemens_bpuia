package com.siemens.medical.bpuia.samples.logging.services.javaservicethatlogscomposite;

import com.siemens.medical.bpuia.samples.logging.services.javaservicethatlogs.JavaServiceThatLogs;
import com.siemens.medical.bpuia.samples.logging.services.javaServiceThatLogs.JavaOperationRequestDocument;
import com.siemens.medical.bpuia.samples.logging.services.javaServiceThatLogs.JavaOperationResponseDocument;

/**
 * Abstract interface generated for component "JavaServiceThatLogsComponent".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.siemens.medical.bpuia.samples.logging.services.javaservicethatlogscomposite.AbstractJavaServiceThatLogsComponent AbstractJavaServiceThatLogsComponent}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractJavaServiceThatLogsComponent
		implements
			JavaServiceThatLogs {

	/**
	 * Implementation of the WSDL operation: JavaOperation	 */
	public abstract JavaOperationResponseDocument javaOperation(
			JavaOperationRequestDocument parameters);

}
