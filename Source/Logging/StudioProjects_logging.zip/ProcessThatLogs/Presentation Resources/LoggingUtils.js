function logInfoToServer(username, msg) {
	throw("Will not log info to server");
	//doLogIt(username, "info", msg);
}

function logTraceToServer(username, msg) {
	throw("Will not log trace to server");
	//doLogIt(username, "trace", msg);
}

function logWarnToServer(username, msg) {
	throw("Will not warn info to server");
	doLogIt(username, "warn", msg);
}

function logDebugToServer(username, msg) {
	throw("Will not log debug to server");
	//doLogIt(username, "debug", msg);
}

function logErrorToServer(username, msg) {
	doLogIt(username, "error", msg);
}

function logFatalToServer(username, msg) {
	doLogIt(username, "fatal", msg);
}

var numSentThisSession = 0;
var maxSentPerSession = 20;

// here is where the WS-caller logic is; 
// decide on using sync vs. async and XHR vs. XDR
// here, use sync and XHR for simplicity
// also, what about authentication, authorization, locating the service?
function doLogIt(username, level, msg) {
	// Some token crowding
	numSentThisSession++;
	if (numSentThisSession > maxSentPerSession) {
		alert("Maxed out persisting to server: " + msg);
		// assume logged to client log
		return;
	}
	
	var requestXmlString = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://www.siemens.com/medical/bpuia/samples/logging/services/ServerLogger/">';
	requestXmlString += '<soapenv:Header/>';
	requestXmlString += '<soapenv:Body>';
	requestXmlString += '<ser:LogToServerRequest>';
	requestXmlString += '<level>' + level + '</level>';
	requestXmlString += '<message>' + username + "-" + msg + '</message>';
	requestXmlString += '</ser:LogToServerRequest>';
	requestXmlString += '</soapenv:Body>';
	requestXmlString += '</soapenv:Envelope>';

	var webServiceUrl = "http://localhost:38080/serverLogger/";
	var request = new XMLHttpRequest();
	request.open("POST", webServiceUrl, false); // synchronous
	request.setRequestHeader("Content-Type", "text/xml");
	request.send(requestXmlString);

	var responseText = request.responseText;
	var responseXmlDoc = request.responseXML;

	if (request.status != 200) {
		alert("Error: status " + request.status);
	}
}